/**
 * Entry script for buildup
 */

/**
 * Module dependencies
 */
const server = require('./lib/server.js');

module.exports = { Server: server.Server }
